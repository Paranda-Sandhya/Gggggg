$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/task.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author:"
    }
  ],
  "line": 2,
  "name": "test the form",
  "description": "",
  "id": "test-the-form",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 3460846575,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "user name is empty",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 11,
      "value": "#||"
    },
    {
      "line": 12,
      "value": "#|s|"
    },
    {
      "line": 13,
      "value": "#|san|"
    },
    {
      "line": 14,
      "value": "#|sandyyyy|"
    }
  ],
  "line": 16,
  "name": "print error message as enter user name",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.user_name_is_empty()"
});
formatter.result({
  "duration": 158709934,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_enter_user_name()"
});
formatter.result({
  "duration": 4169333041,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 2751378448,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "city is empty",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "print error message as enter city name",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.city_is_empty()"
});
formatter.result({
  "duration": 192782556,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_enter_city_name()"
});
formatter.result({
  "duration": 6110424355,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 2918463062,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 24,
  "name": "password is empty",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "print error message as enter password",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.password_is_empty()"
});
formatter.result({
  "duration": 302776587,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_enter_password()"
});
formatter.result({
  "duration": 6133676142,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 2767511655,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 30,
  "name": "gender is not selected",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "print error message as select gender",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.gender_is_not_selected()"
});
formatter.result({
  "duration": 269046911,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_select_gender()"
});
formatter.result({
  "duration": 8150931306,
  "error_message": "org.openqa.selenium.WebDriverException: chrome not reachable\n  (Session info: chrome\u003d70.0.3538.102)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T509\u0027, ip: \u002710.219.34.226\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_131\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\sparanda\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:52980}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.102, webStorageEnabled: true}\nSession ID: 7fcb381ca26234699ea52f947362df20\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.capgemini.project.task.StepDeftask.print_error_message_as_select_gender(StepDeftask.java:119)\r\n\tat ✽.Then print error message as select gender(features/task.feature:31)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 3215091654,
  "status": "passed"
});
formatter.scenario({
  "line": 33,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "languages known is empty",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "print error message as select languages known",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.languages_known_is_empty()"
});
formatter.result({
  "duration": 388505582,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_select_languages_known()"
});
formatter.result({
  "duration": 6071017617,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "check given details",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDeftask.check_given_details()"
});
formatter.result({
  "duration": 2786084042,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "",
  "description": "",
  "id": "test-the-form;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 40,
  "name": "MyNumber is empty",
  "keyword": "When "
});
formatter.step({
  "line": 41,
  "name": "print error message as enter values in MyNumber",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDeftask.mynumber_is_empty()"
});
formatter.result({
  "duration": 548716518,
  "status": "passed"
});
formatter.match({
  "location": "StepDeftask.print_error_message_as_enter_values_in_MyNumber()"
});
