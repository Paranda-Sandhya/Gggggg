
function chkEmpty(){
	var userName=/[a-z]{3,}$/;
	var mobile = /^[7-9]{1}[0-9]{9}$/;
	var email=/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
	//var password=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])\w{6,}$/;
	var password=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,}$/;

	if (document.frm1.userName.value == "") {alert("Please fill the Name");}

	else if (userName.test(document.frm1.userName.value) == false){alert("Please enter the valid Name,Name should be more than 2 letters");}

	else if (document.frm1.city.value == "") {alert("Please fill the city");}

	else if (document.frm1.password.value == "") {alert("Please fill the password");}

	else if (password.test(document.frm1.password.value) == false){alert("Please enter the valid password, password should contain atleast one lower one upper case one number,6 characters,numbers or underscore");}

	else if (document.frm1.gender.value == "") {alert("Please select the gender");}
	/* else if (document.getElementById("male").checked == false && document.getElementById("female").checked == false) {
		window.alert("Please select gender");
		return false;
		}*/
	else if (document.getElementById("eng").checked==false && document.getElementById("tel").checked==false&& document.getElementById("tam").checked == false) {
		window.alert("Please select atleast one language");

	}
	//else if (document.frm1.lang.value == "") {alert("Please select the languages you know");}
	else if (document.frm1.number.value == "") {alert("Please fill the number box");}

	else if (document.frm1.email.value == ""){alert("Please fill the Email");}


	else if (email.test(document.frm1.email.value) == false){alert("Please enter the valid Email");}

	else if(document.frm1.mobile.value == ""){alert("Please fill the mobile number");}

	else if (mobile.test(document.frm1.mobile.value) == false){alert("Please enter the valid mobile number");}

	else {
		alert(" completed Successfully.");
//		window.location="success.html";
	}

}
